package main;

import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Time;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.core.AuthenticationException;

@SpringBootApplication
public class Main {

	public static void main(String[] args) throws IOException, org.apache.http.auth.AuthenticationException {

		String output = "";

		/* // ADD STUDENT TO DB:

		*/

		/* // TYPICAL TESTS
		output += "\n" + runGetRequest("http://localhost:8083/heartbeat", "Alex", "a"); // USER LOGIN AND HEARTBEAT
		output += "\n" + runGetRequest("http://localhost:8083/call/Alex", "Johnson", "c"); // CALL USER
		output += "\n" + runGetRequest("http://localhost:8083/join/0", "Johnson", "c"); // JOIN ROOM
		output += "\n" + runGetRequest("http://localhost:8083/leave", "Johnson", "c"); // LEAVE ROOM

		try {TimeUnit.SECONDS.sleep(5);} catch (Exception e){} // TIMER TO KEEP SENDING HEARTBEATS
		*/
		String jsonStringAlex =
				"{\"name\":\"Vladim\", \"surname\":\"Alex\", \"gender\":\"male\", \"courseID\":\"TINF19\", \"matrikelnummer\":\"000012\", \"passwort\":\"pw1\"}";

		//output += "\n" + HTTP_AUTH_POST_REQUEST( "http://localhost:8083/students/",
		//		jsonStringAlex, "000012", "pw1");

		output += "\n" + runGetRequest("http://localhost:8083/heartbeat", "000012", "pw1");
		output += "\n" + runGetRequest("http://localhost:8083/call/a", "000012", "pw1");

		// Alex and Johnson login.
		// Johnson calls Alex.
		// Alex joins the call.

		Timer timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask()
		{
			@Override
			public void run() {
				try {
					System.out.println(runPostRequest("http://localhost:8083/info"));
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}, 0, 4000);

		System.out.println(output); // print logging output
	}

	static void openWebbrowser(String urlString) throws URISyntaxException, IOException {
		if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
		Desktop.getDesktop().browse(new URI(urlString));
	}
	else
	{
		Runtime rt = Runtime.getRuntime();
		rt.exec("open " + urlString);
	}}

	static String runGetRequest(String urlString, String username, String password)
	{
		System.out.println("Get" + username + " " + password);
		CloseableHttpClient client = HttpClients.createDefault();
		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
		HttpGet httpGet = new HttpGet(urlString);
		try {
			httpGet.addHeader(new BasicScheme().authenticate(credentials, httpGet, null) );
			httpGet.addHeader("matrikelnummer", username);
		} catch (AuthenticationException | org.apache.http.auth.AuthenticationException e){System.out.println(e);}
		try {
			CloseableHttpResponse response = client.execute(httpGet);
			String stringResponse = EntityUtils.toString(response.getEntity());
			client.close();
			return stringResponse;
		} catch (IOException e) {System.out.println(e);}
		return "Request Failed";
	}

	static String runPostRequest(String urlString) throws IOException {

		CloseableHttpClient client = HttpClients.createDefault();

		HttpGet httpPost = new HttpGet(urlString);
		//httpPost.setEntity(new StringEntity(jsonString));
		//httpPost.addHeader("content-type", "application/json");
		CloseableHttpResponse response = client.execute(httpPost);
		String stringResponse = EntityUtils.toString(response.getEntity());
		client.close();
		return stringResponse;
	}
	static String HTTP_AUTH_POST_REQUEST(String target, String jsonString , String username, String password) throws org.apache.http.auth.AuthenticationException, IOException {

		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
		CloseableHttpClient client = HttpClients.createDefault();

		HttpPost httpPost = new HttpPost(target);

		httpPost.addHeader(new BasicScheme().authenticate(credentials, httpPost, null) );
		httpPost.addHeader("matrikelnummer", username);

		if (jsonString != null) {
			httpPost.addHeader("content-type", "application/json");
			httpPost.setEntity(new StringEntity(jsonString));
		}

		CloseableHttpResponse response = client.execute(httpPost);
		String stringResponse = EntityUtils.toString(response.getEntity());

		client.close();

		return stringResponse;
	}
}
