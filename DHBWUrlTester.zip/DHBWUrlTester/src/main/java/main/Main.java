package main;

import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Time;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Main {

	public static void main(String[] args) throws AuthenticationException, IOException {

		String output = "";

		String Alex = createJSON("Alex", "male", "Ibrahimovich",
				"foot", "FIN16", "09984723142");
		// System.out.println(Alex);

		// output += "\n" + HTTP_AUTH_POST_REQUEST( "http://localhost:8083/students/",Alex,
		//		"09984723142", "foot");

		output += "\n" + HTTP_AUTH_GET_REQUEST("http://localhost:8083/heartbeat","09984723142", "foot");
		output += "\n" + HTTP_AUTH_GET_REQUEST("http://localhost:8083/call/009834253","09984723142", "foot");

		// output += "\n" + HTTP_AUTH_GET_REQUEST("http://localhost:8083/call/009834253",
		//		"09984723142", "foot");

		// TESTING SWAP mv certificate.txt certificate1.txt && mv certificate2.txt certificate.txt && mv certificate1.txt certificate2.txt
		// output += "\n" + HTTP_POST_REQUEST("http://localhost:8083/students/009834253/freunde");
        // {matrikelnummer}/freunde
		System.out.println(output);
	}

	static String createJSON(String name,
							 String gender,
							 String surname,
							 String passwort,
							 String courseID,
							 String matrikelnummer) {

		return 		String.format(
						"{\"name\":\"%s\"," +
						"\"surname\":\"%s\"," +
						"\"gender\":\"%s\"," +
						"\"passwort\":\"%s\"," +
						"\"courseID\":\"%s\"," +
						"\"matrikelnummer\":\"%s\"}",

				name, surname, gender, passwort, courseID, matrikelnummer);
	}

	static String HTTP_POST_REQUEST(String urlString, String jsonString)
			throws IOException {
		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(urlString);
		httpPost.setEntity(new StringEntity(jsonString));
		httpPost.addHeader("content-type", "application/json");
		CloseableHttpResponse response = client.execute(httpPost);
		String stringResponse = EntityUtils.toString(response.getEntity());
		client.close();
		return stringResponse;
	}

	static String HTTP_GET_REQUEST(String urlString)
			throws IOException {
		CloseableHttpClient client = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet(urlString);
		CloseableHttpResponse response = client.execute(httpGet);
		String stringResponse = EntityUtils.toString(response.getEntity());
		client.close();
		return stringResponse;
	}

	static String HTTP_AUTH_POST_REQUEST(String target, String jsonString , String username, String password)
			throws org.apache.http.auth.AuthenticationException, IOException {
		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(target);
		httpPost.addHeader(new BasicScheme().authenticate(credentials, httpPost, null) );
		httpPost.addHeader("matrikelnummer", username);
		if (jsonString != null) {
			httpPost.addHeader("content-type", "application/json");
			httpPost.setEntity(new StringEntity(jsonString));
		}
		CloseableHttpResponse response = client.execute(httpPost);
		String stringResponse = EntityUtils.toString(response.getEntity());
		client.close();
		return stringResponse;
	}

	static String HTTP_AUTH_GET_REQUEST(String urlString, String username, String password)
			throws IOException, AuthenticationException {
		CloseableHttpClient client = HttpClients.createDefault();
		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
		HttpGet httpGet = new HttpGet(urlString);
		httpGet.addHeader(new BasicScheme().authenticate(credentials, httpGet, null) );
		httpGet.addHeader("matrikelnummer", username);
		CloseableHttpResponse response = client.execute(httpGet);
		String stringResponse = EntityUtils.toString(response.getEntity());
		client.close();
		return stringResponse;
	}
}
