package models;
import java.util.Objects;

public class Student {

	private String matrikelnummer;
	private String name;
	private String surname;
	private String courseID;
	private String gender;
	private String passwort;


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getCourseID() {
		return courseID;
	}

	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMatrikelnummer() {
		return matrikelnummer;
	}

	public void setMatrikelnummer(String matrikelnummer) {
		this.matrikelnummer = matrikelnummer;
	}

	public String getPasswort() {
		return passwort;
	}

	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}

	@Override
	public String toString() {
		return "{name: " + this.name +
				", surname: " + this.surname +
				", gender: " + this.gender +
				", courseID: " + this.courseID +
				", matrikelnummer: " + this.matrikelnummer +
				", passwort: " + this.passwort + "}";
	}
}

