package models;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;


public class Connection {

  public int room;
  public int state;
  public String url;
  private String token;
  public Date timestamp;
  public String message;
  public List<Integer> rooms;
  public String matrikelnummer;

  public Connection(String token, String matrikelnummer)
  {
    this.url = "";
    this.room = -1;
    this.state = 0;
    this.token = token;
    this.timestamp = new Date();
    this.matrikelnummer = matrikelnummer;
    this.rooms = new ArrayList<Integer>();
  }

  public boolean checkToken(String token){return Objects.equals(this.token, token);}
  public void setTimestamp(){this.timestamp = new Date();}
  public String getUsername(){return this.matrikelnummer;}
  public Date getTimestamp(){return this.timestamp;}
  public int getState(){return this.state;}
  public int getRoom(){return this.room;}

  @Override
  public String toString() {
    return "matrikelnummer: " + this.matrikelnummer +
            ", timestamp: " + this.timestamp +
            ", state: " + this.state +
            ", rooms: " + this.rooms +
            ", room: " + this.room +
            ", message: " + this.message +
            ", url: " + this.url;
  }

}

