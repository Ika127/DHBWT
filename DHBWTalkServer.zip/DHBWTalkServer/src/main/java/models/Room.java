package models;

import java.util.ArrayList;

public class Room {

    public int roomNo;
    public String urlString;
    public ArrayList<Connection> active;
    public ArrayList<Connection> pending;

    public Room(String stringUrl, int roomNo) {
        this.roomNo = roomNo;
        this.urlString = stringUrl;
        this.active = new ArrayList<Connection>();
        this.pending = new ArrayList<Connection>();

        // TODO URLConnection conn = url.openConnection(); bei Dennis
    }

    public void clearRoom(){this.active.clear();this.pending.clear();}
    public int getRoomNo(){return this.roomNo;}

    public void addActive(Connection conn) {

        if (!active.contains(conn)) {
            this.active.add(conn);
        }
        this.pending.remove(conn);
        conn.state = 2;
        conn.room = this.roomNo;
        conn.url = this.urlString;
    }

    public void addPending(Connection conn) {

        if (!active.contains(conn)) {
            if (!pending.contains(conn)) {
                this.pending.add(conn);
                conn.rooms.add(this.roomNo);
                conn.state = 1;
            }
        }
    }

    public void dropConn(Connection conn) {
        this.active.remove(conn);
        this.pending.remove(conn);
    }

    public Boolean checkRoom(Connection conn) {

        if (conn == null)
        {
            return (this.active.isEmpty());
        }
        return (this.active.contains(conn) || this.pending.contains(conn));
    }

    @Override
    public String toString() {
        return "{\"roomNo\": \"" + this.roomNo+
                "\", \"urlString\": \"" + this.urlString +
                "\", \"active\": \"" + this.active +
                "\", \"pending\": \"" + this.pending + "\"}";
    }


}
