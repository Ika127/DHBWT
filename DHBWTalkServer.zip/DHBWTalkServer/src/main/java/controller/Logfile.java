package controller;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class Logfile {
    public static void write(String msg) {
        Logger logger = Logger.getLogger("logger");

        try {
            FileHandler fh = new FileHandler("/Users/ornstein/logfile.log", true);
            logger.addHandler(fh);
            logger.info(msg);
        } catch (IOException e) {
            System.out.println("Logger encountered a problem.");
        }
    }
    public static void clear() {
        Logger logger = Logger.getLogger("logger");
        try {
            FileHandler fh = new FileHandler("/Users/ornstein/logfile.log", true);
            logger.addHandler(fh);
            logger.info("");
        } catch (IOException e) {
            System.out.println("Logger encountered a problem.");
        }
    }
}