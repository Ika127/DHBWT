package controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import models.Connection;
import models.Room;
import models.Student;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.*;

@RestController
class ConnectionController {

  List<Connection> listConnection = new ArrayList<Connection>();
  List<Room> listRoom = new ArrayList<Room>(){{
    add(new Room("https://bbb.dhbw-heidenheim.de/?M=xzNW8jI0M2U3Mu862pnC", 0));
    add(new Room("https://bbb.dhbw-heidenheim.de/?M=eBtgjI0NDNlMushX31Zj", 1));
    add(new Room("https://bbb.dhbw-heidenheim.de/?M=MwIJjI0MmQwMgkoqcKIf", 2));}};
  /*
  Either keep this way or change to a config file containing all url links.
  This would mean an Init function would be necessary to generate and load resources.
  Furthermore TODO generate roomNo automatically with @id or something similar.
   */

  ConnectionController() {
    Cleaner(); // Start the cleaner. Check dead cnxn and rooms.
  }

  private void Cleaner() {

    Timer timer = new Timer();
    timer.scheduleAtFixedRate(new TimerTask() {

      @Override
      public void run() {

        List<Connection> deadConnections = new ArrayList<Connection>();

        if (!listConnection.isEmpty()) {
          Iterator<Connection> connectionIterator = listConnection.iterator();
          /*
          Removing items from the list will cause an Exception to be thrown
          since changes to the objects items relevant to the iteration is forbidden
          TODO double check this to provide a better explanation
          Removing a read item from the iterator fixes the issue
          */

          while (connectionIterator.hasNext()) {
            Connection cnxn = connectionIterator.next(); // get next item of iterator while iterator not empty

            if (new Date().getTime() - cnxn.getTimestamp().getTime() >= 10000) {
              // connection counts as dead if no heartbeat was sent in a duration of milliseconds described by 'cnxn'
              System.out.println("User timed out: '" + cnxn + "'");
              // TODO add this to logfile
              deadConnections.add(cnxn);
              connectionIterator.remove();
            }
          }

          for (Room room : listRoom) {
            if (room.checkRoom(null)) {
              for (Connection zombie_cnxn : room.pending) {
                System.out.println("Zombie User got removed: '" + zombie_cnxn);
                zombie_cnxn.state = 0;
                zombie_cnxn.rooms.remove((Integer) room.roomNo); // remove by Obj. used here != remove by index
              }
              room.pending = new ArrayList<Connection>();
            }
            for (Connection cnxn : deadConnections) {
              // check if rooms contain the dead connections and inform them that it can be dropped
              room.dropConn(cnxn);
            }

          }
        }
      }
    }, 0, 10000);}


  public Connection getConnByUsername(String matrikelnummer) {

    return listConnection.stream()
            .filter(cnxn -> matrikelnummer.equals(cnxn.getUsername()))
            .findAny()
            .orElse(null);
  }


  @GetMapping("/heartbeat")
  public Connection updateConnection(@RequestHeader("matrikelnummer") String matrikelnummer,
                                     @RequestHeader("authorization") String token) {


    Connection cnxn = getConnByUsername(matrikelnummer);

    if (cnxn != null) {
      cnxn.setTimestamp(); // since cnxn exists check if tasks are pending
      if (cnxn.getState() != 0) {
        checkPending(cnxn);
      }
    }
    else {
      cnxn = new Connection(token, matrikelnummer); // new login
      System.out.println("Cnxn established: '" + cnxn + "'");
      listConnection.add(cnxn); // TODO add registration to logfile
      DbController dbController = new DbController();
    }
    return cnxn;
  }

  public void checkPending(Connection checkingConn) {

    Iterator<Room> roomsIterator = listRoom.iterator();
    // iterate through all rooms. This time iterator is not necessary but in the future it might help.

    while (roomsIterator.hasNext())
    {
      Room room = roomsIterator.next();
      if (room.checkRoom(checkingConn) && !checkingConn.rooms.contains(room.roomNo))
      // if checkingConn either active in room or pending for room add to its rooms.
      // instead of wiping all rooms and then checking: add it this way since a heartbeat might occur between the wipe and the new init.
      {
        checkingConn.rooms.add(room.roomNo);
      }
    }
  }
  
  @GetMapping("/call/{matrikelnummer}")
  public void callConnection(@RequestHeader("matrikelnummer") String requestingUserId,
                             @RequestHeader("authorization") String id,
                             @PathVariable("matrikelnummer") String acceptingUserId) {

    Connection requestingConn = getConnByUsername(requestingUserId);
    Connection acceptingConn = getConnByUsername(acceptingUserId);

    if (requestingConn == null || acceptingConn == null) {requestingConn.message = "User '" + acceptingUserId + "' does not exist"; return;}
    if (requestingConn == acceptingConn) {requestingConn.message = "'How much can you know about yourself if you have never been in a fight?'"; return;}
    if (acceptingConn.state == 2) {requestingConn.message = "User '" + acceptingUserId + "' is busy."; return;}

    switch (((requestingConn.getState() == 0) ? 0 : 1) + "" + ((requestingConn.getState() == 0) ? 0 : 1)) {
      case "01", "11", "00" -> {

        Room emptyRoom = listRoom.stream()
                .filter(room -> room.checkRoom(null).equals(true))
                .findAny()
                .orElse(null);

        if (emptyRoom == null) {
          requestingConn.message = "No free Rooms available.";
          return;
        }
        emptyRoom.addActive(requestingConn);
        emptyRoom.addPending(acceptingConn);
      }
      case "20", "21" ->
              listRoom.get(requestingConn.getRoom()).addPending(acceptingConn);
    }
  }

  @GetMapping("/leave")
  public void leaveRoom(@RequestHeader("matrikelnummer") String matrikelnummer,
                        @RequestHeader("authorization") String id) {
    Connection leavingConn = getConnByUsername(matrikelnummer);
    listRoom.get(leavingConn.room).dropConn(leavingConn);
    leavingConn.rooms.remove((Integer)leavingConn.room);
    leavingConn.state = 0;
    leavingConn.room = -1;
    leavingConn.url = "";
  }


  @GetMapping("/room/{roomNo}")
  public String checkRoom(@RequestHeader("matrikelnummer") String matrikelnummer,
                          @RequestHeader("authorization") String id,
                          @PathVariable int roomNo) {
    Connection checkingConn = getConnByUsername(matrikelnummer);
    Room room = listRoom.get(roomNo);
    if (room.pending.contains(checkingConn)) {
      return room.toString();
    }
    return null;
  }

  @GetMapping("/join/{roomNo}")
  public String joinRoom(@RequestHeader("matrikelnummer") String requestingUserId,
                       @RequestHeader("authorization") String id,
                       @PathVariable("roomNo") int roomNo) {

    Connection joiningConn = listConnection.stream()
            .filter(cnxn -> requestingUserId.equals(cnxn.getUsername()))
            .findAny()
            .orElse(null);

    Room room = listRoom.get(roomNo);
    if (!room.checkRoom(joiningConn))  {joiningConn.message = "This room is private."; return null;}
    room.addActive(joiningConn);
    return room.urlString;
  }

  @GetMapping("/info")
  public String getInfo()
  {
    StringBuilder infoString = new StringBuilder();
    for(Room room:listRoom) {
      infoString.append(room).append("\n");
    }
    for(Connection cnxn:listConnection) {
      infoString.append(cnxn).append("\n");
    }
    System.out.println("/info\n" + infoString);
    return infoString.toString();
  }
}



