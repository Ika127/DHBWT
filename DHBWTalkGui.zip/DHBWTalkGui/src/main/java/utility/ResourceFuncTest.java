package utility;

import org.junit.jupiter.api.Assertions;

import java.util.List;

class ResourceFuncTest {

    //Multiple object test
    @org.junit.jupiter.api.Test
    void JSON_String_toList() {
        ResourceFunc resourceFunc = ResourceFunc.getInstance();

        String response = "[{\"name\":\"Testname\",\"surname\":\"Testnachname\",\"courseID\":\"Testkurs\"}," +
                "{\"name\":\"Testname\",\"surname\":\"Testnachname\",\"courseID\":\"Testkurs\"}]";
        List<String> objects = resourceFunc.JSON_String_toList(response);
        Assertions.assertTrue(objects.stream().count() == 2);
    }

    //Single object test
    @org.junit.jupiter.api.Test
    void JSON_String_toList_singleObject() {
        ResourceFunc resourceFunc = ResourceFunc.getInstance();

        String response = "[{\"name\":\"Testname\",\"surname\":\"Testnachname\",\"courseID\":\"Testkurs\"}]";
        List<String> objects = resourceFunc.JSON_String_toList(response);
        //Assertions.assertTrue(objects.contains("{\"name\":\"Testname\",\"surname\":\"Testnachname\",\"courseID\":\"Testkurs\"}"));
        String test = "{\"name\":\"Testname\",\"surname\":\"Testnachname\",\"courseID\":\"Testkurs\"}";
        Assertions.assertEquals(objects.get(0), test);
    }

    //Multiple object list
    @org.junit.jupiter.api.Test
    void stringToList() {
        ResourceFunc resourceFunc = ResourceFunc.getInstance();

        String response = "[{\"name\":\"Testname\",\"surname\":\"Testnachname\",\"courseID\":\"Testkurs\"}," +
                "{\"name\":\"Testname\",\"surname\":\"Testnachname\",\"courseID\":\"Testkurs\"}]";
        List<String> objects = resourceFunc.StringToList(response);
        Assertions.assertTrue(objects.stream().count() != 0);
    }
}