package utility;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class Logfile {
    public static void LOG(String[] args) throws IOException {
        Logger logger = Logger.getLogger("logger");
        FileHandler fh = new FileHandler("./logfile.log");
        logger.addHandler(fh);
    }
    public static void clear() throws IOException {
        Logger logger = Logger.getLogger("logger");
        FileHandler fh = new FileHandler("./logfile.log");
        logger.addHandler(fh);
        logger.info("");
    }
}