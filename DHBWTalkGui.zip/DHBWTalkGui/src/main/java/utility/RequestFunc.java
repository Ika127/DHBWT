package utility;

import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import javax.swing.*;
import java.io.IOException;

public class RequestFunc {

    static public String partialURL = "http://localhost:8083/";

    static public Boolean HTTP_BASIC_AUTH(String matrikelnummer, String password) {
        String response = HTTP_AUTH_GET_REQUEST("students/", matrikelnummer, password);
        switch (response) {
            case "false":
            case "null":
                // TODO wrong login info
        }
        return null;
    }

    static public String HTTP_AUTH_GET_REQUEST(String targetURL, String matrikelnummer, String password)
    {
        CloseableHttpClient client = HttpClients.createDefault();
        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(matrikelnummer, password);
        HttpGet httpGet = new HttpGet("http://" + targetURL);
        try {
            httpGet.addHeader(new BasicScheme().authenticate(credentials, httpGet, null) );
            httpGet.addHeader("matrikelnummer", matrikelnummer);
        } catch (org.apache.http.auth.AuthenticationException e){System.out.println(e);}
        try {
            CloseableHttpResponse response = client.execute(httpGet);
            String stringResponse = EntityUtils.toString(response.getEntity());
            client.close();
            return stringResponse;
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e + "\nPlease contact your system administrator!");
        }
        return null;
    }

    static String HTTP_AUTH_POST_REQUEST(String target, String jsonString , String matrikelnummer, String password) {

        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(matrikelnummer, password);
        CloseableHttpClient client = HttpClients.createDefault();

        HttpPost httpPost = new HttpPost("http://" + target);
        try {
            httpPost.addHeader(new BasicScheme().authenticate(credentials, httpPost, null));
            httpPost.addHeader("matrikelnummer", matrikelnummer);

            if (jsonString != null) {
                httpPost.addHeader("content-type", "application/json");
                httpPost.setEntity(new StringEntity(jsonString));
            }

            CloseableHttpResponse response = client.execute(httpPost);
            String stringResponse = EntityUtils.toString(response.getEntity());

            client.close();
            return stringResponse;
        }
        catch (org.apache.http.auth.AuthenticationException | IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
