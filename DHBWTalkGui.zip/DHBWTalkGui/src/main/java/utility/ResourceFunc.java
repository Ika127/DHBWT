package utility;

import com.google.gson.JsonObject;
import com.sun.tools.javac.Main;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import user.User;

import java.awt.*;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.net.HttpURLConnection;

import javax.imageio.ImageIO;
import javax.naming.AuthenticationException;
import javax.swing.*;

public class ResourceFunc {
	//Singleton Instance Creation
	private static ResourceFunc instance = null;
	private ResourceFunc() {}
	public static ResourceFunc getInstance()
	{
		if(instance == null)
			instance = new ResourceFunc();
		return instance;
	}
	public JsonObject heartbeatJSON = null;
	public User appUser = null;
	private String startup_path;
	public boolean FriendRequest_LockPopUp = false;
	public boolean IncomingCallLockPopUp = false;
	public final static String osName = System.getProperty("os.name");
	public final static String javaHome=System.getProperty("java.home");


	//Methods and Functions
	//Images
	///Scales image to given measurements
	///Takes >>Image URL, Image Width and Height<<
	///Returns >>Scaled Image<<
	public Image ScaleImage(String imgURL, int width, int height)
	{
		try {
			InputStream inputStream = getClass().getResourceAsStream(imgURL);
			ImageIcon unscaledUserImage = new ImageIcon(ImageIO.read(inputStream));
			Image unscaledImage = unscaledUserImage.getImage();
			return unscaledImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	//Reads given file and returns string containing json information
	public String ReadJSON(String filePath)
	{
		String json = null;
		try {
			FileReader reader;
			reader = new FileReader(filePath);
			BufferedReader bufferedReader = new BufferedReader(reader);
			String line;

			while((line = bufferedReader.readLine()) != null)
			{
				// certificate.txt only has 1 line > 'name':'test','surname':'test','courseID':'tin19','id':'1'
				json = line;
			}

			reader.close();

		} catch (IOException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e + "\nPlease contact your system administrator!");
		}

		return json;
	}

	//Writes .txt file
	public void WriteTxt(String filepath, String information)
	{
		//Append specified text file
		try(FileWriter fw = new FileWriter(filepath, true);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter out = new PrintWriter(bw))
		{
			out.println(information);
		} catch (IOException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e + "\nPlease contact your system administrator!");
		}
	}

	//Interpret json array as list
	public List<String> JSON_String_toList(String getResponse)
	{

		System.out.println(getResponse);
		//getResponse: "{json}" or "[{json1},{json2},...]"
		List<String> userObjects = new ArrayList<String>();

		boolean multipleObjects = getResponse.startsWith("[");
		if(multipleObjects)
		{
			//multiple jsons
			userObjects = StringToList(getResponse);
		}
		else if((!getResponse.isEmpty()) && (!getResponse.equals("keine Freunde")))
		{
			//single json
			//Cut out brackets []
			getResponse = getResponse.substring(
					getResponse.indexOf("["),
					getResponse.indexOf("]")
			);
			userObjects.add(getResponse);
		}
		return userObjects;
	}

	//Fills list with multiple json objects
	public List<String> StringToList(String getResponse)
	{
		boolean loop = true;
		List<String> objects = new ArrayList<>();
		do {
			objects.add(
					getResponse.substring(
							getResponse.indexOf("{"),
							getResponse.indexOf("}") + 1
					)
			);
			//Last item ?
			if(getResponse.indexOf(",{") != -1) {
				getResponse = getResponse.substring(
						getResponse.indexOf(",{") + 1,
						getResponse.indexOf("]") + 1
				);
			}
			else
				loop = false;
		} while (loop);

		return objects;
	}

	static public String HTTP_AUTH_GET_REQUEST(String targetURL, String matrikelnummer, String password)
	{
		CloseableHttpClient client = HttpClients.createDefault();
		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(matrikelnummer, password);
		HttpGet httpGet = new HttpGet("http://" + targetURL);
		try {
			httpGet.addHeader(new BasicScheme().authenticate(credentials, httpGet, null) );
			httpGet.addHeader("matrikelnummer", matrikelnummer);
		} catch (org.apache.http.auth.AuthenticationException e){System.out.println(e);}
		try {
			CloseableHttpResponse response = client.execute(httpGet);
			String stringResponse = EntityUtils.toString(response.getEntity());
			client.close();
			return stringResponse;
		} catch (IOException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e + "\nPlease contact your system administrator!");
		}
		return null;
	}


	//Execute POST or GET depending on boolean "GET" (true = GET, false = POST)
	public String HTTP_REQUEST(String targetURL, String urlParameters, String RequestMethod)
	{
		HttpURLConnection connection = null;

		try {
			//Create connection
			URL url = new URL("http://" + targetURL);
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod(RequestMethod);


			connection.setRequestProperty("Content-Type", "application/json; utf-8");
			connection.setRequestProperty("Accept", "application/json");

			//Cache/Output settings
			//connection.setUseCaches(false);
			connection.setDoOutput(true);

			//Send request
			if(urlParameters != null) {
				if(!RequestMethod.equals("GET")) {
					try (OutputStream os = connection.getOutputStream()) {
						byte[] input = urlParameters.getBytes("utf-8");
						os.write(input, 0, input.length);
					}
				}
			}

			//Read response
			try(BufferedReader br = new BufferedReader(
					new InputStreamReader(connection.getInputStream(), "utf-8"))) {
				StringBuilder response = new StringBuilder();
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}

				return response.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e + "\nPlease contact your system administrator!");

			return null;
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	//Open web browser with specified link
	public void OpenBBB(String URL)
	{
		Desktop desktop = Desktop.getDesktop();
		try {
			//specify the protocol along with the URL
			URI oURL = new URI(
					URL);
			desktop.browse(oURL);
		} catch (URISyntaxException | IOException e) {
			e.printStackTrace();
		}
	}

	//Create or delete auto run bat file TODO
	public void RunOnStartup() throws IOException, URISyntaxException {
		String pathToJAR = System.getProperty("user.home") + File.separatorChar
				+ "eclipse-workspace" + File.separatorChar
				+ "DHBWTalk.GUI" + File.separatorChar
				+"target/DHBWTalk.GUI-1.0-SNAPSHOT.jar";
		//Windows (Developer Note: Working on windows 10)
		if(osName.startsWith("Windows"))
		{
			startup_path = System.getProperty("user.home") + File.separatorChar
					+ "AppData" +File.separatorChar+ "Roaming" +File.separatorChar +"Microsoft"
					+ File.separatorChar + "Windows" + File.separatorChar
					+ "Start Menu"+File.separatorChar
					+"Programs"+File.separatorChar+"Startup"+File.separatorChar;

			File startup = new File(startup_path + File.separatorChar + "dhbwtalk_runonstartup.bat");

			//Disable autorun
			if(startup.exists())
			{
				startup.delete();
				JOptionPane.showMessageDialog(null, "\nRun on startup disabled!");
			}
			//enable autorun
			else {
				//Create file and print command
				File file = new File(startup_path + "dhbwtalk_runonstartup.bat");
				file.createNewFile();
				PrintWriter writer = new PrintWriter(file, "UTF-8");
				writer.println("javaw -Xmx200m -jar " + pathToJAR);
				writer.close();
				JOptionPane.showMessageDialog(null, "\nRun on startup enabled!");
			}
		}
		//Mac OS
		else if(osName.startsWith("Mac"))
		{

			//Run Main on startup
			startup_path = "/System/Library/LaunchDaemons/";

			File startup = new File(startup_path + File.separatorChar + "dhbwtalk_runonstartup.bat");

			//disable autorun
			if(startup.exists())
			{
				startup.delete();
				JOptionPane.showMessageDialog(null, "\nRun on startup disabled!");
			}
			//enable autorun
			else {
				File file = new File(startup_path + "dhbwtalk_runonstartup.plist");
				PrintWriter writer = new PrintWriter(file);
				writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
				writer.println("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">");
				writer.println("<plist version=\"1.0\">");
				writer.println("<dict>");
				writer.println("   <array>");
				writer.println("      <string>" + javaHome + File.separatorChar + "bin" + File.separatorChar + "java</string>");
				writer.println("      <string>-cp</string>");
				writer.println("      <string>" + pathToJAR + "</string>");
				writer.println("      <string>" + "Main" + "</string>");
				writer.println("   </array>");
				writer.println("   <key>RunAtLoad</key>");
				writer.println("   <true/>");
				writer.println("</dict>");
				writer.println("</plist>");
				writer.close();
				JOptionPane.showMessageDialog(null, "\nRun on startup enabled!");
			}
		}
		/*@ECHO OFF
set CLASSPATH=.
set CLASSPATH=%CLASSPATH%;path/to/needed/jars/my.jar

%JAVA_HOME%\bin\java -Xms128m -Xmx384m -Xnoclassgc ro.my.class.MyClass*/
	}
}
