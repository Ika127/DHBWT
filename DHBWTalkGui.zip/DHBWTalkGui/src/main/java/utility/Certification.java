package utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Objects;

import com.google.gson.JsonObject;
import org.apache.http.auth.AuthenticationException;
import user.User;

import javax.swing.*;

import com.google.gson.Gson;

public class Certification {
	//Singleton Instance Creation
	private static Certification instance = null;
	private Certification() {}
	public static Certification getInstance()
	{
		if(instance == null)
			instance = new Certification();
		return instance;
	}

	private User appUser = null;
	public User getAppUser() {
		return appUser;
	}
	private String connectionID = null;
	public String getConnectionID() {return connectionID;}

	private ResourceFunc resourceFunc = ResourceFunc.getInstance();
	private String keyPath_ = new JFileChooser().getFileSystemView().getDefaultDirectory().toString()
			+ File.separatorChar + "dhbwtalk" + File.separatorChar;
	private String keyPath = new JFileChooser().getFileSystemView().getDefaultDirectory().toString() + File.separatorChar + "dhbwtalk" + File.separatorChar;
	
	//Verifies whether a valid authentication code is present on the system or not
	public boolean checkCertificate(boolean sendCertificate)
	{
		boolean exists;

		//Check certificate
		String filePath = keyPath + "certificate.txt";
		File key = new File(filePath);
		exists = key.exists();

		//Send certificate
		if(exists)
		{
			//Get connection ID
			String JSON = resourceFunc.ReadJSON(filePath);
			String _connectionID = JSON.substring(
					JSON.indexOf(";") + 1, JSON.length()
			);
			this.connectionID = _connectionID;
			//Get JSON
			JSON = JSON.substring(0, JSON.indexOf(";"));

			Gson gson = new Gson();
			if(sendCertificate) {
				if (JSON != null) {
					String response = RequestFunc.HTTP_AUTH_GET_REQUEST("localhost:8083/students/", this.appUser.getId(), this.appUser.getPasswort());
					if(response.compareTo("false") == 0 || response.compareTo("null") == 0)
					{
						//Password not valid
						exists = false;
					}
				}
			}
			this.appUser = gson.fromJson(JSON, User.class);
			resourceFunc.appUser = this.appUser;
		}
		return exists;
	}
		
	//Saves authentication file under (e.g.) ~/Documents/dhbwtalk
	public void saveCertificate(String userJSON)
	{
		String filePath = keyPath + "certificate.txt";
		try
		{
			//Heartbeat id
			String connectionID = new Gson().fromJson(RequestFunc.HTTP_AUTH_GET_REQUEST("localhost:8083/heartbeat",
					resourceFunc.appUser.getId(),
					resourceFunc.appUser.getPasswort()),
					JsonObject.class).get("matrikelnummer").toString();

			//Write file
			FileWriter writer = new FileWriter(filePath, true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			
			bufferedWriter.write(userJSON + ";" + connectionID);
			bufferedWriter.close();

			//Send user information to server
			String response = RequestFunc.HTTP_AUTH_POST_REQUEST("localhost:8083/students/", userJSON, resourceFunc.appUser.getId(), resourceFunc.appUser.getPasswort());
			if(response == null)
				JOptionPane.showMessageDialog(null, "\nServer appears to be offline or unreachable!");
		}
		catch(IOException e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e + "\nPlease contact your system administrator!");
			File cert = new File(keyPath + "certificate.txt");
			cert.delete();
		}
		// https://www.example-code.com/java/pfx_create_from_pem_files.asp
	}
}
