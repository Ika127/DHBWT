package main_frame;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import user.User;
import utility.ResourceFunc;

public class RegistrationFrame extends JFrame implements ActionListener {
	private User appUser;
	private ResourceFunc resourceFunc = ResourceFunc.getInstance();
	private boolean x_Dispatch = true;
	
	private Container container;
	private JLabel title;
	private JLabel name;
	private JTextField _name;
	private JLabel surname;
	private JTextField _surname;
	private JLabel courseID;
	private JTextField _courseID;
	private JLabel matrNr;
	private JTextField _matrNr;
	private JLabel gender;
	private JRadioButton male;
    private JRadioButton female;
    private JRadioButton x_gender;
    private ButtonGroup gengp;
    private JLabel password;
    private JTextField _password;
    private JButton submit;
    private JButton reset;
    
	public RegistrationFrame()
	{
		//Frame
		setTitle("Registration Form");
		setBounds(300, 90, 900, 600);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setResizable(false);
		
		//Container
		container = getContentPane();
		container.setLayout(null);
		container.setBackground(new Color(0x72727F));
		
		//Title
		title = new JLabel("Registration Form");
		title.setFont(new Font("Arial", Font.PLAIN, 30));
		title.setSize(300, 30);
		title.setLocation(300, 30);
		container.add(title);
		
		//Name
		name = new JLabel("Name");
		name.setFont(new Font("Arial", Font.PLAIN, 20));
        name.setSize(100, 20);
        name.setLocation(100, 100);
        container.add(name);
        //Name text field
        	_name = new JTextField();
        	_name.setFont(new Font("Arial", Font.PLAIN, 15));
            _name.setSize(150, 20);
            _name.setLocation(200, 100);
            container.add(_name);
        
        //Surname
        surname = new JLabel("Surname");
        surname.setFont(new Font("Arial", Font.PLAIN, 20));
        surname.setSize(100, 20);
        surname.setLocation(100, 150);
        container.add(surname);
        //Surname text field
        	_surname = new JTextField();
        	_surname.setFont(new Font("Arial", Font.PLAIN, 15));
        	_surname.setSize(150, 20);
        	_surname.setLocation(200, 150);
        	container.add(_surname);
        	
    	//Gender
    	gender = new JLabel("Gender");
        gender.setFont(new Font("Arial", Font.PLAIN, 20));
        gender.setSize(100, 20);
        gender.setLocation(100, 200);
        container.add(gender);
        //Gender buttons
	        male = new JRadioButton("Male");
	        male.setFont(new Font("Arial", Font.PLAIN, 15));
	        male.setSelected(true);
	        male.setSize(75, 20);
	        male.setLocation(200, 200);
	        container.add(male);
	        
	        female = new JRadioButton("Female");
	        female.setFont(new Font("Arial", Font.PLAIN, 15));
	        female.setSelected(false);
	        female.setSize(80, 20);
	        female.setLocation(275, 200);
	        container.add(female);

			x_gender = new JRadioButton("X");
			x_gender.setFont(new Font("Arial", Font.PLAIN, 15));
			x_gender.setSelected(false);
			x_gender.setSize(75, 20);
			x_gender.setLocation(355, 200);
			container.add(x_gender);

	        gengp = new ButtonGroup();
	        gengp.add(male);
	        gengp.add(female);
	        gengp.add(x_gender);
        
        //CourseID
        courseID = new JLabel("Course");
        courseID.setFont(new Font("Arial", Font.PLAIN, 20));
        courseID.setSize(100, 20);
        courseID.setLocation(100, 250);
        container.add(courseID);
    	//Course text field
        	_courseID = new JTextField();
        	_courseID.setFont(new Font("Arial", Font.PLAIN, 15));
        	_courseID.setSize(150, 20);
        	_courseID.setLocation(200, 250);
        	container.add(_courseID);

        //Matriculation number
		matrNr = new JLabel("M.Nr.");
		matrNr.setFont(new Font("Arial", Font.PLAIN, 20));
		matrNr.setSize(100, 20);
		matrNr.setLocation(100, 300);
		container.add(matrNr);
		//Matriculation number text field
			_matrNr = new JTextField();
			_matrNr.setFont(new Font("Arial", Font.PLAIN, 15));
			_matrNr.setSize(150, 20);
			_matrNr.setLocation(200, 300);
			container.add(_matrNr);

		//Password
		password = new JLabel("Password");
		password.setFont(new Font("Arial", Font.PLAIN, 20));
		password.setSize(100,20);
		password.setLocation(100, 350);
		container.add(password);
		//Password text field
			_password = new JTextField();
			_password.setFont(new Font("Arial", Font.PLAIN, 15));
			_password.setSize(150,20);
			_password.setLocation(200, 350);
			container.add(_password);

    	//Submit button
		submit = new JButton("Submit");
		submit.setFont(new Font("Arial", Font.PLAIN, 15));
		submit.setSize(100, 20);
		submit.setLocation(150, 400);
		submit.addActionListener(this);
		container.add(submit);
		
		//reset button
		reset = new JButton("Reset");
		reset.setFont(new Font("Arial", Font.PLAIN, 15));
        reset.setSize(100, 20);
        reset.setLocation(270, 400);
        reset.addActionListener(this);
        container.add(reset);
        
    	setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == submit)
		{
			String selectedGender = male.isSelected() ? "Male" : "Female";
			selectedGender = x_gender.isSelected() ? "X-Gender" : selectedGender;
			if(_name.getText().length()  != 0 
					&& _surname.getText().length() != 0 
					&&_courseID.getText().length() != 0
					&&_matrNr.getText().length() != 0
					&&_password.getText().length() != 0)
			{

				String userInformation = String.format("{'name':'%s','surname':'%s','courseID':'%s','gender':'%s','id':'%s','passwort':'%s'}",
						_name.getText(), _surname.getText(), _courseID.getText(), selectedGender, _matrNr.getText(), _password.getText());

				//Either create user object and save it globally or await server response with account information (latter one seems more logical)
				Gson gson = new Gson();
				this.appUser =  gson.fromJson(userInformation, User.class);
				resourceFunc.appUser = this.appUser;
				//userInformation > Server
				//Wait for response before closing
			}
			x_Dispatch = false;
			this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
		}
		else if(e.getSource() == reset)
		{
			String empty = "";
			_name.setText(empty);
			_surname.setText(empty);
			_courseID.setText(empty);
			_matrNr.setText(empty);
			_password.setText(empty);
		}
	}
	
	//Getter
	public User getAppUser()
	{
		return this.appUser;
	}
	
	public boolean getDispatch()
	{
		return x_Dispatch;
	}
}