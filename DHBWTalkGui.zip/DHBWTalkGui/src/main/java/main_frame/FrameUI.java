package main_frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonObject;
import user.AddUser;
import user.User;
import user.UserFrame;
import user.UserFrameBuilder;
import utility.ResourceFunc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.google.gson.Gson;
import utility.VerticalLayout;

public class FrameUI extends JFrame{
	ResourceFunc resourceFunc = ResourceFunc.getInstance();
	
	//Main Panes
		private JPanel mainPane;
		private JPanel innerPane;

		public JPanel getContactsPane() {
			return contactsPane;
		}

		private JPanel contactsPane;
		private JPanel infoPane;
		private JPanel userPane;
		private JLabel userPaneLabel;

		private JLabel infoPane_UserInformation;

		private JPanel addFriend;
	/**
	 * Create the frame.
	 */
	public FrameUI() {		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		//Main pane, Grid
		mainPane = new JPanel();
		mainPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		mainPane.setLayout(new GridLayout());
		mainPane.setBackground(new Color(0x444450));
		setContentPane(mainPane);
		
		//Inner pane containing all gui elements
		innerPane = new JPanel();
		innerPane.setLayout(new BorderLayout(10, 0));
		innerPane.setBackground(new Color(0x444450));
		mainPane.add(innerPane);
		
		//Contacts pane for contact overview
		contactsPane = new JPanel();
		contactsPane.setLayout(new BorderLayout(10, 10));
		contactsPane.setBackground(new Color(0x54545D));
		contactsPane.setPreferredSize(new Dimension(250, 100));
		innerPane.add(contactsPane, BorderLayout.WEST);
		
		//----------ContactsPane Sub-Panels ----------

		// > New class for users ("Frames.UserFrame") with buttons etc > graphics later!
		
		ContactsPane_Setup(contactsPane);
		
		//-------------------------------------------
		
		//Info pane
		infoPane = new JPanel();
		infoPane.setBackground(new Color(0x54545D));
		infoPane.setLayout(new BorderLayout(10,10));
		
		InfoPane_Setup(infoPane);
		
		innerPane.add(infoPane, BorderLayout.CENTER);
		
		//ensures that every layout and size we just defined gets applied before becoming visible
		pack();
	}
	
	//Creates necessary sub panels for ContactsPane
	public void ContactsPane_Setup(JPanel contactsPane)
	{
		userPane = new JPanel();
		userPane.setLayout(new BorderLayout());
		userPane.setBackground(new Color(0x72727F));
		userPane.setPreferredSize(new Dimension(230, 75));
		
		////////////
		//User info pane containing title
		JPanel contactsPaneHeader = new JPanel();
		contactsPaneHeader.setBackground(new Color(0x72727F));
		JLabel userInfoLabel = new JLabel("User List");
		userInfoLabel.setFont(new Font(userInfoLabel.getText(), Font.BOLD, 16));
		contactsPaneHeader.add(userInfoLabel);
		
		////////////
		//Dynamically insert online contacts
		//Online User Space
		JPanel contacts = new JPanel();
		//userSpace.setLayout(new BoxLayout(userSpace, BoxLayout.Y_AXIS));
		contacts.setLayout(new VerticalLayout(5, 0, 1));
		contacts.setBackground(new Color(0x54545D));

		//Add User button
		AddUser addUser = new AddUser();
		contacts.add(addUser);

			AddFriends_ToGUI(contacts);
		
		JScrollPane userSpaceScrollable = new JScrollPane(contacts);
		userSpaceScrollable.getViewport().setPreferredSize(new Dimension(150, 460));
		userSpaceScrollable.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		userSpaceScrollable.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		userSpaceScrollable.getVerticalScrollBar().setPreferredSize(new Dimension(10,10));
		userSpaceScrollable.getVerticalScrollBar().setUnitIncrement(16);
		
		////////////
		//User
		ImageIcon userImage = new ImageIcon(resourceFunc.ScaleImage("/images/test-user.png", 50, 50));
		userPaneLabel = new JLabel();
		userPaneLabel.setIcon(userImage);
		userPane.add(userPaneLabel);
			//Run on Startup
			JLabel autoRunLabel = new JLabel();
			ImageIcon cogwheel = new ImageIcon(resourceFunc.ScaleImage("/images/running-stick-figure.png", 25, 25));
			autoRunLabel.setIcon(cogwheel);
			autoRunLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			autoRunLabel.addMouseListener(new MouseAdapter()
			{
				//Autorun
				@Override
				public void mouseClicked(MouseEvent e)
				{
					try {
						resourceFunc.RunOnStartup();
					} catch (IOException ioException) {
						ioException.printStackTrace();
					} catch (URISyntaxException uriSyntaxException) {
						uriSyntaxException.printStackTrace();
					}

				}
			});
			autoRunLabel.setText("<html>(Run on <br/> start-up)</html>");
		userPane.add(autoRunLabel, BorderLayout.EAST);
		
		contactsPane.add(contactsPaneHeader, BorderLayout.NORTH);
		contactsPane.add(userSpaceScrollable, BorderLayout.CENTER);
		contactsPane.add(userPane, BorderLayout.SOUTH);
	}

	//Adds friends from api to gui
	public void AddFriends_ToGUI(JPanel contacts)
	{
		if(resourceFunc.appUser != null) {
			//Get friends
			List<String> friends = new ArrayList<>();


			friends = resourceFunc.JSON_String_toList(
					resourceFunc.HTTP_REQUEST("localhost:8083/students/"
									+ resourceFunc.appUser.getId() + "/freunde",
							null, "GET")
			);

			//Add every friend to gui
			Gson gson = new Gson();
			User user;
			for (int i = 0; i < friends.stream().count(); i++) {
				user = gson.fromJson(friends.get(i), User.class);
				if (user != null) {
					UserFrame a = new UserFrameBuilder(user, false)
							.setName(user.getName())
							.setBackground(new Color(0x72727F))
							.setDimension(225, 70).build();
					a.addMouseListener(
							new MouseAdapter() {
								//Change cursor
								@Override
								public void mouseEntered(MouseEvent e) {
									setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
								}

								//Change cursor
								@Override
								public void mouseExited(MouseEvent e) {
									setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
								}

								//Update info pane
								@Override
								public void mouseClicked(MouseEvent e) {
									Update_InfoPane(a.getUser());
								}
							}
					);
					contacts.add(a);
				}
			}
			contacts.revalidate();
			contacts.repaint();
		}
	}

	//Sets and updates application user display
	public void Update_ApplicationUser(User appUser)
	{
		this.userPaneLabel.setText("<html>" + appUser.getSurname() + ", " + appUser.getName()
				+ "<br/>" + appUser.getCourseID() + "</html>");
	}

	//Creates and attaches necessary sub panels to InfoPane
	public void InfoPane_Setup(JPanel infoPane)
	{
		//Title / header
		JPanel infoPaneHeader = new JPanel();
		infoPaneHeader.setBackground(new Color(0x72727F));
		JLabel infoLabel = new JLabel("Info");
		infoLabel.setFont(new Font(infoLabel.getText(), Font.BOLD, 16));
		infoPaneHeader.add(infoLabel);
		infoPane.add(infoPaneHeader, BorderLayout.NORTH);

		//Body containing information
		JPanel infoPaneBody = new JPanel();
		infoPaneBody.setBackground(new Color(0x72727F));
		infoPaneBody.setLayout(new BorderLayout(5, 5));

			//User information
			JPanel infoUser = new JPanel();
			infoUser.setBackground(new Color(0x72727F));
			infoUser.setLayout(new BorderLayout());
			infoUser.setPreferredSize(new Dimension(infoPaneBody.getWidth(), 150));
				ImageIcon userImage = new ImageIcon(resourceFunc.ScaleImage("/images/test-user.png", 100, 100));
				//Text gets changed when hovering over a user
				infoPane_UserInformation = new JLabel();
				infoPane_UserInformation.setFont(new Font(infoPane_UserInformation.getText(), Font.BOLD, 30));
				infoPane_UserInformation.setIcon(userImage);
				infoUser.add(infoPane_UserInformation, BorderLayout.WEST);
			infoPaneBody.add(infoUser, BorderLayout.NORTH);

			//History information
			JPanel infoHistory = new JPanel();
			infoHistory.setBackground(new Color(0x72727F));

			//Scrollable history panel
			JScrollPane infoHistoryScrollablle = new JScrollPane(infoHistory);
			//userSpaceScrollable.getViewport().setPreferredSize(new Dimension(150, 460));
			infoHistoryScrollablle.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			infoHistoryScrollablle.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			infoHistoryScrollablle.getVerticalScrollBar().setPreferredSize(new Dimension(10,10));
			infoHistoryScrollablle.getVerticalScrollBar().setUnitIncrement(16);

			infoPaneBody.add(infoHistoryScrollablle, BorderLayout.CENTER);

		infoPane.add(infoPaneBody, BorderLayout.CENTER);
	}

	public void Update_InfoPane(User user)
	{
		infoPane_UserInformation.setText("<html>" + "Name: " + user.getSurname() + ", " + user.getName()
				+ "<br/>" + "Course: " + user.getCourseID() + "</html>");
	}
}
