package main_frame;

import com.google.gson.Gson;
import user.User;
import utility.RequestFunc;
import utility.ResourceFunc;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PopUp extends JFrame implements ActionListener {
    private ResourceFunc resourceFunc = ResourceFunc.getInstance();
    private boolean x_Dispatch = true;

    private Container container;
    private JLabel title;
    private JLabel accept;
    private JLabel decline;
    private ImageIcon acceptIcon;
    private ImageIcon declineIcon;
    private JPanel callButtons;

    private String callerMessage;
    private String acceptPath;
    private String declinePath;

    public PopUp(User caller, String kindOfPopUP)
    {
        var f = this;
        //Check caller kind
        if(kindOfPopUP.equals("call") )
        {
            callerMessage = " is calling...";
            acceptPath = "/images/accept.png";
            declinePath = "/images/decline.png";
        }
        else if(kindOfPopUP.equals("leave")) {

            callerMessage = "";
            acceptPath = "/images/decline.png";
            declinePath = "/images/accept_friend.png";

        }
        else //friend request
        {
            callerMessage = " wants you as a friend!";
            acceptPath = "/images/accept_friend.png";
            declinePath = "/images/decline_friend.png";
        }

        //Frame
        setTitle("Call");
        setBounds(300, 90, 300, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);

        //Container
        container = getContentPane();
        container.setLayout(new BorderLayout());
        container.setBackground(new Color(0x72727F));

        //Title
        title = new JLabel(caller.getName() + callerMessage);
        title.setFont(new Font("Arial", Font.PLAIN, 20));
        title.setSize(300, 100);
        title.setLocation(100, 100);
        container.add(title, BorderLayout.NORTH);


        //Buttons
        callButtons = new JPanel();
        callButtons.setLayout(new BorderLayout());
        callButtons.setLocation(100, 150);
        callButtons.setBackground(new Color(0x72727F));

        //Accept
        accept = new JLabel();
        acceptIcon = new ImageIcon(resourceFunc.ScaleImage(acceptPath, 75, 75));
        accept.setIcon(acceptIcon);

        accept.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                if(kindOfPopUP.equals(("leave"))) {

                    RequestFunc.HTTP_AUTH_GET_WRAPPED("http://localhost:8083/leave/", resourceFunc.appUser);

                    // TODO check if leave or leave(roomNO)
                    // TODO check old code
                    /*RequestFunc.HTTP_AUTH_GET_REQUEST(
                            "localhost:8083/leave/",
                            resourceFunc.appUser.getId(),
                            resourceFunc.appUser.getPasswort());*/

                    resourceFunc.IncomingCall_LockPopUp = false;
                }

                if(kindOfPopUP.equals("call")) {

                        String targetURL = RequestFunc.HTTP_AUTH_GET_WRAPPED("http//localhost:8083/join/" +
                                        caller.getSurname(),
                                resourceFunc.appUser);

                        // TODO check old code
                        /* String targetURL = RequestFunc.HTTP_AUTH_GET_REQUEST(
                                    "localhost:8083/join/" + caller.getSurname(), // hack to get roomNo
                                    resourceFunc.appUser.getId(),
                                    resourceFunc.appUser.getPasswort()); */

                        if (targetURL == null || targetURL.isEmpty()) {
                            JOptionPane.showMessageDialog(null,
                                    resourceFunc.heartbeatJSON.get("message").toString());
                            return;
                        }

                    try {
                        ResourceFunc.openBrowser(targetURL);
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        JOptionPane.showMessageDialog(null, "\nMeeting was canceled. Please wait and retry.");
                        resourceFunc.IncomingCall_LockPopUp = false;
                        return;
                    }

                    User caller = new User(null);
                    caller.setName("leave call");

                    PopUp popUp = new PopUp(caller, "leave");

                    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
                    int x = (int) ((dimension.getWidth() - popUp.getWidth()) / 2);
                    int y = (int) ((dimension.getHeight() - popUp.getHeight()) / 2);
                    popUp.setLocation(x, y);
                }

                //friend request
                else {
                    Gson gson = new Gson();
                    String userInformation = gson.toJson(caller, User.class);
                    resourceFunc.HTTP_REQUEST("localhost:8083/students/"
                    + resourceFunc.appUser.getId() + "/" + "freunde", userInformation, "PUT");
                    //Disable popup lock
                    resourceFunc.FriendRequest_LockPopUp = false;
                }
                PopUp.super.dispose();
            }
        });

        if(kindOfPopUP.equals("leave")) {
            callButtons.add(accept, BorderLayout.CENTER);
        }
        else {
            callButtons.add(accept, BorderLayout.WEST);
        }

        //Decline
        decline = new JLabel();
        declineIcon = new ImageIcon(resourceFunc.ScaleImage(declinePath, 75, 75));
        decline.setIcon(declineIcon);
        decline.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                if(kindOfPopUP.equals("call")) {
                    RequestFunc.HTTP_AUTH_GET_WRAPPED("http://localhost:8083/leave/" + caller.getSurname(), resourceFunc.appUser);

                    //TODO check old code
                    /*    RequestFunc.HTTP_AUTH_GET_REQUEST(
                        "localhost:8083/leave/" + caller.getSurname(),
                        resourceFunc.appUser.getId(),
                        resourceFunc.appUser.getPasswort());
                    */
                }
                PopUp.super.dispose();
                //Disable popup lock
                resourceFunc.FriendRequest_LockPopUp = false;
                resourceFunc.IncomingCall_LockPopUp = false;
            }
        });

        if (!kindOfPopUP.equals("leave")) {
            callButtons.add(decline, BorderLayout.EAST);
        }

        container.add(callButtons, BorderLayout.SOUTH);


        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
}
