package user;

public class User {
	private String name = null;
	private String surname = null;
	private String courseID = null;
	private String gender = null;
	//German word for password because of our database controller
	private String passwort = null;
	private final String id;

	private String matrikelnummer = null; //TODO
	public String getMat() {
		return matrikelnummer;
	}

	
	public User(String id)
	{
		this.id = id;
	}

	
	//Getters and Setters for class properties
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getCourseID() {
		return courseID;
	}

	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}

	public String getGender() {
		return gender;
	}

	public String getPasswort() {
		return passwort;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getId() {
		return id;
	}	
}
