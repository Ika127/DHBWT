package user;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import main_frame.PopUp;
import utility.RequestFunc;
import utility.ResourceFunc;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class UserFrame extends JPanel{
	ResourceFunc resourceFunc = ResourceFunc.getInstance();

	//User ID and name received from server event
	private User user;
	//private final int id;
	private String name = "";
	private String surname = "";
	private String courseID = "";
	private String gender = "";
	private ImageIcon userIcon = new ImageIcon(resourceFunc.ScaleImage("/images/test-user.png", 30, 30));
	private ImageIcon callIcon = new ImageIcon(resourceFunc.ScaleImage("/images/telephone.png", 30, 30));
	private ImageIcon addIcon = new ImageIcon(resourceFunc.ScaleImage("/images/add.png", 30, 30));
	private ImageIcon currentIcon;
	private boolean module_UserSearch = false;
	
	private Dimension dimension;
	private Color color;
	
	//Constructors
	public UserFrame(User user)
	{
		this.user = user;
	}
	
	//Class constructor
	public UserFrame(User user, String name, Dimension dimension, Color color, boolean module_userSearch)
	{
		this.user = user;
		//for manual override purposes
		this.name = name;
		this.surname = user.getSurname();
		this.courseID = user.getCourseID();
		this.gender = user.getGender();

		this.color = color;
		this.module_UserSearch = module_userSearch;
		
		this.setBackground(color);
		this.setPreferredSize(dimension);
		this.setLayout(new BorderLayout(5,5));
		//Listener for highlight effect of hovered contact
		this.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseEntered(MouseEvent e)
			{
				changeColor(color.brighter());
			}
			@Override
			public void mouseExited(MouseEvent e)
			{
				changeColor(color);
			}
		});

		//Icon
		if(module_UserSearch)
			this.currentIcon = addIcon;
		else
			this.currentIcon = callIcon;
		
		label();
	}
	
	//Design elements of every Frames.UserFrame created
	public void label()
	{
		//User icon and name
		JLabel label = new JLabel();
		label.setIcon(userIcon);
		label.setText("<html>" +this.surname + ", " + this.name + "<br/>" + this.courseID + "</html>");
		this.add(label, BorderLayout.WEST);
		
		//Set icon
		label = new JLabel();
		label.setIcon(currentIcon);
		label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		//Listener for e.g. call (Event > Server)
		label.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				if(module_UserSearch)
				{
					//ADD user
					String userInformation = String.format("{\"name\":\"%s\",\"surname\":\"%s\",\"courseID\":\"%s\"}",
							user.getName(), user.getSurname(), user.getCourseID());
					String response = resourceFunc.HTTP_REQUEST("localhost:8083/students/" + resourceFunc.appUser.getId()
							+ "/freunde", userInformation, "POST");
					JOptionPane.showMessageDialog(null, response);
				}
				else
				{
					// TODO THIS IS THE XXXXXXX GET_ID AUFPASSEN HIER MUSS FIX HER
					System.out.println("http://localhost:8083/call/"+user.getId());
					System.out.println(resourceFunc.appUser.getId() + resourceFunc.appUser.getPasswort());
					String targetURL = RequestFunc.HTTP_AUTH_GET_WRAPPED("localhost:8083/call/"+user.getId(), resourceFunc.appUser);

					System.out.println(targetURL + " 112,9");
					//String targetURL = ResourceFunc.HTTP_AUTH_GET_REQUEST(
						//			String.format("localhost:8083/call/%s", user.getMat()),
						//			resourceFunc.appUser.getId(),
							//		resourceFunc.appUser.getPasswort());

					if (targetURL == null || targetURL.isEmpty()) {
						JOptionPane.showMessageDialog(null,resourceFunc.heartbeatJSON.get("message").toString());
						return;
					}

					ResourceFunc.openBrowser(targetURL);
					User caller = new User(null);
					caller.setName("leave call");
					PopUp popUp = new PopUp(caller, "leave");
					Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
					int x = (int) ((dimension.getWidth() - popUp.getWidth()) / 2);
					int y = (int) ((dimension.getHeight() - popUp.getHeight()) / 2);
					popUp.setLocation(x, y);
					resourceFunc.IncomingCall_LockPopUp = true;
				}
			}
			//Enlarge call image
			@Override
			public void mouseEntered(MouseEvent e)
			{
				if(module_UserSearch)
				{
					currentIcon = new ImageIcon(resourceFunc.ScaleImage("/images/add.png", 50, 50));
					changeIcon((JLabel)e.getSource(), currentIcon);
				}
				else
				{
					currentIcon = new ImageIcon(resourceFunc.ScaleImage("/images/telephone.png", 50, 50));
					changeIcon((JLabel)e.getSource(), currentIcon);
				}
				changeColor(color.brighter());
			}
			
			//Shrink call image
			@Override
			public void mouseExited(MouseEvent e)
			{
				if(module_UserSearch)
				{
					currentIcon = new ImageIcon(resourceFunc.ScaleImage("/images/add.png", 30, 30));
					changeIcon((JLabel)e.getSource(), currentIcon);
				}
				else
				{
					currentIcon = new ImageIcon(resourceFunc.ScaleImage("/images/telephone.png", 30, 30));
					changeIcon((JLabel)e.getSource(), currentIcon);
				}
				changeColor(color);
			}
		});
		this.add(label, BorderLayout.EAST);
	}
	
	
	//Changes an image to a new one
	public void changeIcon(JLabel label, ImageIcon icon)
	{
		label.setIcon(icon);
	}
	
	//Changes background color
	public void changeColor(Color color)
	{
		this.setBackground(color);
	}
	
	//Getters and Setters
	public String getID()
	{
		return user.getId();
	}
	
	public String getName()
	{
		return name;
	}
	
	public User getUser() {
		return user;
	}

	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setDimension(int x, int y)
	{
		this.dimension = new Dimension(x, y);
	}
}
