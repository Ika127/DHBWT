package user;

import java.awt.Color;
import java.awt.Dimension;

//Builder class for "Frames.UserFrame"
public class UserFrameBuilder {
	//Meta information
	//User ID and name received from server event which are needed
	//in order to, for example, prevent two instances of the same user
	//to be present.
	private User user;
	//private final int id;
	private String name = "";
	private boolean module_userSearch = false;
	private Dimension dimension;
	private Color backgroundColor;
	
	//Builder Constructors
	public UserFrameBuilder(User user)
	{
		this.user = user;
	}
	
	public UserFrameBuilder(User user, boolean module_userSearch)
	{
		this.user = user; 
		this.module_userSearch = module_userSearch;
	}
	
	public UserFrameBuilder(User user, String name, Dimension dimension)
	{
		this.user = user;
		this.name = name;
	}
	
	//Builder Functions
	//name property
	public UserFrameBuilder setName(String name)
	{
		this.name = name;
		return this;
	}
	
	//background color property
	public UserFrameBuilder setBackground(Color color)
	{
		this.backgroundColor = color;
		return this;
	}
	
	//Sets dimension of to be created Frames.UserFrame
	public UserFrameBuilder setDimension(int x, int y)
	{
		this.dimension = new Dimension(x, y);
		return this;
	}
	
	//Builds(returns) class instance
	public UserFrame build()
	{
		return new UserFrame(user, name, dimension, backgroundColor, module_userSearch);
	}
}
