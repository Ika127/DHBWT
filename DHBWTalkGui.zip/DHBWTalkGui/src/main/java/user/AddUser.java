package user;

import utility.ResourceFunc;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AddUser extends JPanel {
	private ResourceFunc resourceFunc = ResourceFunc.getInstance();
	private ImageIcon addIcon = new ImageIcon(resourceFunc.ScaleImage("/images/add.png", 30, 30));
	private Color color = new Color(0x72727F);
	
	public AddUser()
	{
		Create_AddLabel();
	}
	
	public void Create_AddLabel()
	{
		this.setPreferredSize(new Dimension(237, 55));
		this.setBackground(new Color(0x72727F));
		
		final JLabel label = new JLabel();
		label.setIcon(addIcon);
		label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		label.addMouseListener(new MouseAdapter()
				{
					//Enlarge add image
					@Override
					public void mouseEntered(MouseEvent e)
					{
						addIcon = new ImageIcon(resourceFunc.ScaleImage("/images/add.png", 50, 50));
						label.setIcon(addIcon);
					}
					
					//Shrink add image
					@Override
					public void mouseExited(MouseEvent e)
					{
						addIcon = new ImageIcon(resourceFunc.ScaleImage("/images/add.png", 30, 30));
						label.setIcon(addIcon);
					}

					//Open user search
					@Override
					public void mouseClicked(MouseEvent e)
					{
						UserSearchFrame usf = UserSearchFrame.getInstance();
						usf.addWindowListener(new WindowAdapter() {
							@Override
							public void windowClosing(WindowEvent e)
							{
								//clear user list
								usf.ClearFoundUsers();
							}
						});

						usf.setVisible(true);
					}
				});
		this.add(label, BorderLayout.CENTER);
	}
}
