package user;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import com.google.gson.Gson;
import utility.RequestFunc;
import utility.ResourceFunc;
import utility.VerticalLayout;

public class UserSearchFrame extends JFrame implements ActionListener {
	//Singleton > only one search window may be open at any time!
	private static UserSearchFrame instance = null;
	
	public static UserSearchFrame getInstance()
	{
		if(instance == null)
			instance = new UserSearchFrame();
		return instance;
	}

	private List<User> users_found = new ArrayList<>();
	ResourceFunc resourceFunc = ResourceFunc.getInstance();

	private Container container;
	private JPanel searchParameterPanel;
	private JLabel name;
	private JTextField _name;
	private JLabel surname;
	private JTextField _surname;
	private JLabel courseID;
	private JTextField _courseID;
	private JButton search;
	private JPanel userListPanel;
	private JPanel submitPanel;
	private JButton add;
	
	private UserSearchFrame()
	{
		//Frame
		setTitle("User Search");
		setBounds(300, 90, 750, 600);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setResizable(false);

		//Container
		container = getContentPane();
		container.setLayout(null);
		container.setBackground(new Color(0x72727F));
		
		//Search parameters
		searchParameterPanel = new JPanel();
		searchParameterPanel.setBackground(new Color(0x72727F));
		searchParameterPanel.setLayout(null);
		searchParameterPanel.setBounds(0, 0, 900, 100);
		searchParameterPanel.setLocation(0, 0);
			//Fields
			name = new JLabel("Name");
			name.setFont(new Font("Arial", Font.PLAIN, 15));
			name.setSize(75, 20);
			name.setLocation(25, 25);
	        searchParameterPanel.add(name);
	        	_name = new JTextField();
	        	_name.setFont(new Font("Arial", Font.PLAIN, 10));
	            _name.setSize(100, 20);
	            _name.setLocation(75, 25);
	            searchParameterPanel.add(_name);
            surname = new JLabel("Surname");
            surname.setFont(new Font("Arial", Font.PLAIN, 15));
            surname.setSize(100, 20);
            surname.setLocation(200, 25);
            searchParameterPanel.add(surname);
            	_surname = new JTextField();
            	_surname.setFont(new Font("Arial", Font.PLAIN, 10));
            	_surname.setSize(100, 20);
            	_surname.setLocation(275, 25);
            	searchParameterPanel.add(_surname);
        	courseID = new JLabel("Course");
        	courseID.setFont(new Font("Arial", Font.PLAIN, 15));
        	courseID.setSize(75,20);
        	courseID.setLocation(400, 25);
        	searchParameterPanel.add(courseID);
        		_courseID = new JTextField();
        		_courseID.setFont(new Font("Arial", Font.PLAIN, 10));
        		_courseID.setSize(75, 20);
        		_courseID.setLocation(475, 25);
        		searchParameterPanel.add(_courseID);
    		search = new JButton("Search");
    		search.setFont(new Font("Arial", Font.PLAIN, 15));
    		search.setSize(100, 20);
    		search.setLocation(600, 25);
    		search.addActionListener(this);
    		container.add(search);
	        
        container.add(searchParameterPanel);
		
		//User list
		userListPanel = new JPanel();
		userListPanel.setLayout(new VerticalLayout(5, 0, 0));
		userListPanel.setBackground(new Color(0x54545D));
		
		//Scroll pane for users
		JScrollPane userSpaceScrollable = new JScrollPane(userListPanel);
		userSpaceScrollable.getViewport().setPreferredSize(null);
		userSpaceScrollable.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		userSpaceScrollable.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		userSpaceScrollable.getVerticalScrollBar().setPreferredSize(new Dimension(10,10));
		userSpaceScrollable.getVerticalScrollBar().setUnitIncrement(16);
		userSpaceScrollable.setBounds(10, 100, 700, 400);
		
		container.add(userSpaceScrollable);
		
		//Submit panel
		submitPanel = new JPanel();
		submitPanel.setLayout(new BorderLayout());
		
		add = new JButton();
		add.setFont(new Font("Arial", Font.PLAIN, 15));
		add.setSize(100, 20);
		add.addActionListener(this);
		container.add(submitPanel);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == search)
		{
			//Search users
			String searchName = _name.getText().length() == 0 ? "null" : _name.getText();
			String searchSurname = _surname.getText().length() == 0 ? "null" : _surname.getText();
			String searchCourse = _courseID.getText().length() == 0 ? "null" : _courseID.getText();
			String response = RequestFunc.HTTP_AUTH_GET_REQUEST("http//:localhost:8083/students/" + searchName + "/"
					+ searchSurname + "/"
					+ searchCourse, resourceFunc.appUser.getId(), resourceFunc.appUser.getId());
			//Add found users to container
			List<String> usersFound = new ArrayList<>();
			usersFound = resourceFunc.JSON_String_toList(response);
			for(int i = 0; i < usersFound.stream().count(); i++)
			{
				AddUser(usersFound.get(i));
			}
		}
	}

	//Adds user to user list panel
	public void AddUser(String _user)
	{
		Gson gson = new Gson();
		User user = gson.fromJson(_user, User.class);
		boolean abort = false;

		//You can still search for yourself due to http response!

		//Verify new user hasn't been added to the list yet
		for(int i = 0; i < users_found.stream().count(); i++)
		{
			if(users_found.get(i) == user)
			{
				abort = true;
				break;
			}
		}

		//Add user frame and add added user to list
		if(!abort) {
			UserFrame a = new UserFrameBuilder(user, true)
					.setName(user.getName())
					.setBackground(new Color(0x72727F))
					.setDimension(625, 100).build();
			userListPanel.add(a);
			container.revalidate();
			container.repaint();
			users_found.add(user);
		}
	}

	//Clears found users list
	public void ClearFoundUsers()
	{
		users_found.clear();
		userListPanel.removeAll();
	}
}
